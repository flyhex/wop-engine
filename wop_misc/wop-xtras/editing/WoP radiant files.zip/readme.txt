World of Padman 	WoP Radiant pack for Gtk/NetRadiant 1.5 or newer
by Kai-Li		last updated December 17th 2011

Features:
1. includes support for World of Padman + entities.def + default_shaderlist.txt 
2. modified build-menue with new build-commands (like -custinfoparms and -flares)
3. modified help-menue with links to WoP web pages
4. includes bspcwop.exe for creating the botfile (aas)

Extract the content into your Radiant installation directory.
The package contains all relative paths.
Compatible to World of Padman 1.6 or newer

visit:	http://www.worldofpadman.com
	http://editing.worldofpadman.com



       t
     tRRt
    tRRS t
    SRRtt t                                         sRRRRRRRRSSSSt
   CRRSttt tt                                              SRRRRRSssSs
   SRRStCCtt t                            Sc                  sRRRRRSSRc
  tRRRRtsCCct                           sR                      tRRRRRSsSC
  cRRSStcsSCCttt                      SRS                        SRRRRRRSsSc
  CRSSC ttCssCt t                   sRSS                          SRRRRRRRSC
  SScsc   ttssCcttt                tRSS                            RRRRRRRRSsc
  RRtCct    tCSSCt                CRRSt                            tRRRRRRRRCsC
  RRRtcsctt   SCSsC t            tRRSS                              SRRRRRRRSCsctCsSSSC
  RC tssssCtt  tcsSCttCt         RRRSC                              CRRRRRRRCt tttcctttRc
  t  CRRsssCtt  tcssCt tt       tRRRSC                              CRRRRRRs ttCCCCCCCctRt
    ttCRsCsssCt  ttCsCttS       RRRRSs                              sRRRC  tccccctttcccttSC
       tCRRRssCtt  ccCttC      CRRRRSS                              RR ttccctttttttttttcttR
        ttRRSCsCctttC  SS      SRRRRSss                            tt ccttttttttt tttttcttR
          t CRsssCt   RRSSCt   RRRRRRSSc                         t tcctttttt      tttttctcs
            tSSsCCCtSSsSsCttts RRRRRRRsSc                      ttccctttt       ttttttcctts
             tttttsRRRRSC   tttRRRRRRRRsss              tRSRStttctttt      tttttttccctttt
              ttCtcRSRRRCt    tRRRRRRRRRSst             RRR tcctttt   ttttttttcccctt  t
                  tCRRsSRCct   SRRRRRRRRRRCSc         CRRRsCcttttttttttttcttttttttCCCtS
                   t tCCCRSCSt cRRRRRRRRRRRSssSs   tCSsSRRsctttttttttttttttccCCCCCsssts
                    tttRSsSRsctSSRRRRRRRRRRRRRSSssSSSRRRRRCtttttttccccCCCCCsCCCCCssstC
                      ttcSCsRRRSsSRRRRRRRRRRRRRRRRRRRRRRRRctttttttttccCSsCCCCCcCCCtct
                       c CCCSRRCCsRRRRRRRRRRRRRSRRRRRRRRRScttttttttttccCccssccccCcc
                        t cCCsSSCSsRRRRRRRRRRRs RRRRRRRRRCtttttttttttttttttttccttsSSRs
                         t tCsStCCSSRRRRRRRRRs tRRRRRRRRSttttttttttttttttttttttSRRRSSSSt
                         tRSSst tcCstSRRRRRRs  sRRRRRRRCtttttttttttttttsSttttRRRRRRRRRSSR
                          sCccCt  CCcCsSRRRC   RRRRRRSctttttttttttttttCRRSRCtRRRRRRRRRRssRt
                          CsSSCct StsSstCCs   tRRRRSctttttttttttttttttCRCCStSRRRRRRRRRSSSSRt
                         tscSsSCcttR ttCstCCCCCccctttttttttttttttttttttttt tRRRRRRRSsRRRRRRs
                         sttSCsSccctcssSStCCCCCccttttttttttttttttsSSSsccCSRRRRSSRSSSstCRRRRSSC
                         C   tCsSsCcttcsRstCCCCsCCCccccccccttCRRSCCsRRRRRRRRSSSsssssssCRRRRRRSSS
                         t tRRRCsSSCCCsSRRRsctttttttttttCsRRRRRRStCRRRRRRRRSCCCccctttcCtRRRRRRRSSt
                        c cRccCcsSSSSSCtSScCRRRRSttttRCSRRRRRRRRRtSRRRRRRSCctttttttttttctRRRRSSSSSs
                        s sSCSscsst sSSCCtssRRRSS   ctttcsSRRRRRRtRRRRRRsccttttttttt ttCtRRRRSSSSSS
                      tSs SRssstCt  SSCSCt CScCsRs sCttttttcSRRRRRRRRRsctttttttttttt  tctcRRRRSSsSSs
                       Sc CRRRCCC  tSSCRRSt  CSSttsSttttttttttSRRRRRRSttttttttttttttt  tttRRRRRSssSCs
                        C  t   s   tsSStcCcCSRRttttttCCtCttttttcSRRRsttttttttCttttttt  tttSRRRRRSssRsc
                         cCt   t   tSSttttctsRStt   ttCcsctttttttRRsttttttttSCc ttttt  tttCRRRRRSSCRSCt
                           Ss t     Rctt ttttcRsttt tcCCsstttttttSCttttttttttCsttttttt ttttRRRRRRSsSRst
                            CRS     CS t  ttcccRSCttcCCsScStttttttttttttttttcCcttttttt ttttRRRRRRSsSRSC
                              C       Ct ttttcRRRRRRRSCSSSSttttttsStttttttttCCCt tttttttttcRRRRRRSssRRC
                                        SSSRRSsSRRRRRsRssCtStttttcsssCttttttCsCt tttttttttCRRRRRRSssRRC
                                       SsttttttCcRRRRSSSstS c ttS   ttRSttccCCCt tttttttttcSRRRRRSssRRs
                                      CRstt  tttCSRRRRRRSR  tSStt Ss stsRRSSSSSs tttttttttctcRRRSSssSRst
                                     tsRRtttttttSRSSRRRSRSStSRs S  tRtccsRRRRRRs ttttttttccRRRRRSSCsSRSt
                                     tSRRStttttsRSSRRRRRRRSsSRcts   SSstCSRRRRRs ttttttttctRRRRRSSCsSRSt
                                     tSRRRttttttssRSRRSRRRRSRRcSC   cRcCCsRRRRRs tttttttcctSRRRRSSsSSRSc
                                     tSRRRttttttCSRsSRRRRRRRRRCSR   RRtCCsRRRRRSSSSSSsCtcCtCRRRRSSssSRRs
                                     tsRRRRRSsssRSCsSSRRRRRRRRSCRRRRRRtcCsRRRRRSRRSSSSSRRRCcRRRRSSssSRRs
                                      ssRRRRRRRRsSsCCSSRRRRRRSRStSsRRSCCCSRRRRSRRRSsssSRRRRRRRRRRSSCSSRS
                                       CsSRRRRRRCSSsCsSSSRRRstCcSt CttsSSSSSSSRRRSssssSRRRRRRRRRRSSCsSRRt
                                        CsRRRRRRSsSSsCCsSSSRt ttttsSSsccCCssSRRRRSSsssSRRRRRRRRRRRSsCsSRC
                                      tCsSSssCssRCSCSCcCsSSS ttttttttttttcCCRRRRRSSSSSSRRRRRRRRRRRRsssSSSC
                                    CsSSSSSRRRRRRSsScSCCCsSS ttttcsc tttttcsRRRRRRSSSSRRRRRRRRRRRRRRSssSRSCt
                                  tcSSSSSSSSRRRRRRCSSSSCCCsRtt  ttcCttttttCSRRRSSSRRRRRRRRRRRRRRRRRRRSssSRSsC
                                tcCSSSSSSSSSSSRRRRSsSSSSCcSCt   ttcCt ttttSSSSSSSSSSSSSSSSSRRRRRRSSRRRSSsSSRSCCt
                               tcCSSSsssSSSSSSSRRRSCSRSSsSCSt   ttcCt ttttSRCsssssssssssSSSSSRRRRSSSSSSSssSSRSCssttt
                               cSSSSsCCssSSSSSSRRRRSRRSt tRRc   ttcCC ttttcttttttttttttcCssssRRRRRSSSSSSSSsssSSRSSss
                              cSSSsCcCCsSSSRSSRRRRRRsCSRRRRRS    ttCCtttts ttttttttttttttttcCCsRRRRSSsCSSSSSSSSSSSsS
                            tCsSsCCcCsSSSSRSSSRRRRRRRRRRRRRRRt   ttcCtttts tCctttttttttttttcCCCcRRRSSCStRSSSSSSSsCt
                           tcSSsCccCSSSSRRSSSSRRRRRRRRRRRRRRRS t sccCstttStCSctttttttttCCCCCCCcccRSSSCS   tsSSCt
                          tcSSsCcCssSSSSC SSSSRRRRRRRSSSSRRRRRc CscCSSstttcCRcttttttcCCsSsCCcttctSSSScSt
                          CCSSscCsSSSC   tsSSSRRRRRSSsSSSSRRRRRttSctSSSRRRRRRctttttcCsCttttctttccSSSSCsc
                         tCsSsCCsSSs     CSSSSRRRSSsCsSSSSSRRRRSttRSscRstCttSsttttCccctttttctcttSRRSSSCR
                         cCSSsSSSCt      SSSSSRRSssssSSSSSSRRRRSttstcSs tttcRsttttttCCCtttctCSSSSRRRRSSCt
                         CsSSSSst        SSSSSRRSssSs    tRRRRRtttctCSStCStcRSttttttCCCcctCt     csRRRRRSSt
                         CSSSSs          cCSSSSSSSSt      sRRRs ttctCSRRSSSSRSttttttCCSRSs           tcCt
                         CSSsc            ssSSSSsS        CRRSsRRSctSsSSSSSsSSttttttCcsSSS
                         CSsCt            RCSSSSSC        sRRsSSSRCtsSSSSSSSRRtttttccCRRRSC
                         CCC               RssSSs        CsRSsSssRCCRRSSSRRRSSRScttCRRRRRRSc
                         tt                 cRss        CsRRSSsCsRRSSStcSRRRssSSSRRRRRSSRRRSC
                         t                    CR       ssC sSSssSRRSSs tSRRRCCSSSRRSSSSSSRRRs
                                                      st  cSSssSRRRSSC tSRRRCcSSSRRSsssSSRRRRSt
                                                         CsRRSSRRRRSSC tSRRRctSSSRRSssSSRRRRRRSs
                                                  csSsssSSSSSSRRRRRSSC cSRRRCtsSSRSSSSSRRRSSSSSSSt
                                                sCsSSRRRRRRRRRSRRRRsSCtcSRRRCtCSSRRSSRRSSRRRRRSSSSSSSSSc
                                               CsSRRRRRRRRRRRRRRSRSsSCCCSRRRCtcSSRRRRSSRRRRRRRRRRRRRRSCs
                                               SSRRRRRRRRRRRRRRRRRSsSC tSRRRsttsSSRSSRRRRRRRRRRRRRRRRRSCt
                                               SSRRRRRRRRRRRRRRRRSSSSCctsRRRSctcSSSRRRRRRRRRRRRRRRRRRRRSC
                                               SSRRRRRRRRRRRRRRRRSSsSCCcCSRRSsCCSSRRRRRRRRRRRRRRRRRRRRRSC
                                              sSRRRRRRRRRRRRRRRRRSssScttCSRRSSssSSRRRRRRRRRRRRRRRRRRRRRSC
                                               tSSSSsSSSSRRRRRRRSRRSSCcccsscRRSSsCSSSSSRRRRRRRRRRRRSSSSRs
                                                     cCSSSRRRSst  tSCCssCCcst        tsSSsssSSSSSSSSssSSRt
                                                                                         tCSSSSSSSSSSRSs


