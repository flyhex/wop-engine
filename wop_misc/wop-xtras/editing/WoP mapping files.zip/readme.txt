World of Padman 	mapping files
by Kai-Li		last updated December 17th 2011

This package includes important files to make maps for World of Padman,
including custinfoparms.txt and sample map files for Spray Your Color, 
BigBalloon and Capture the Lolly game modes. Many thanks to Wakey for
additional particel and shader effects. This package does not include
mapobjects (md3 files) and environment box textures. Since WoP 1.5 they 
are already part of the release. Exctract those files from wop_002.pk3 
(models/mapobjects/...) and wop_005.pk3 (env/...) if you like, but there
is no need to do it.


Extract the content into your World of Padman installation directory.
The package contains all relative paths.
Compatible to World of Padman 1.6 or newer.

visit:	http://www.worldofpadman.com
	http://editing.worldofpadman.com



       t
     tRRt
    tRRS t
    SRRtt t                                         sRRRRRRRRSSSSt
   CRRSttt tt                                              SRRRRRSssSs
   SRRStCCtt t                            Sc                  sRRRRRSSRc
  tRRRRtsCCct                           sR                      tRRRRRSsSC
  cRRSStcsSCCttt                      SRS                        SRRRRRRSsSc
  CRSSC ttCssCt t                   sRSS                          SRRRRRRRSC
  SScsc   ttssCcttt                tRSS                            RRRRRRRRSsc
  RRtCct    tCSSCt                CRRSt                            tRRRRRRRRCsC
  RRRtcsctt   SCSsC t            tRRSS                              SRRRRRRRSCsctCsSSSC
  RC tssssCtt  tcsSCttCt         RRRSC                              CRRRRRRRCt tttcctttRc
  t  CRRsssCtt  tcssCt tt       tRRRSC                              CRRRRRRs ttCCCCCCCctRt
    ttCRsCsssCt  ttCsCttS       RRRRSs                              sRRRC  tccccctttcccttSC
       tCRRRssCtt  ccCttC      CRRRRSS                              RR ttccctttttttttttcttR
        ttRRSCsCctttC  SS      SRRRRSss                            tt ccttttttttt tttttcttR
          t CRsssCt   RRSSCt   RRRRRRSSc                         t tcctttttt      tttttctcs
            tSSsCCCtSSsSsCttts RRRRRRRsSc                      ttccctttt       ttttttcctts
             tttttsRRRRSC   tttRRRRRRRRsss              tRSRStttctttt      tttttttccctttt
              ttCtcRSRRRCt    tRRRRRRRRRSst             RRR tcctttt   ttttttttcccctt  t
                  tCRRsSRCct   SRRRRRRRRRRCSc         CRRRsCcttttttttttttcttttttttCCCtS
                   t tCCCRSCSt cRRRRRRRRRRRSssSs   tCSsSRRsctttttttttttttttccCCCCCsssts
                    tttRSsSRsctSSRRRRRRRRRRRRRSSssSSSRRRRRCtttttttccccCCCCCsCCCCCssstC
                      ttcSCsRRRSsSRRRRRRRRRRRRRRRRRRRRRRRRctttttttttccCSsCCCCCcCCCtct
                       c CCCSRRCCsRRRRRRRRRRRRRSRRRRRRRRRScttttttttttccCccssccccCcc
                        t cCCsSSCSsRRRRRRRRRRRs RRRRRRRRRCtttttttttttttttttttccttsSSRs
                         t tCsStCCSSRRRRRRRRRs tRRRRRRRRSttttttttttttttttttttttSRRRSSSSt
                         tRSSst tcCstSRRRRRRs  sRRRRRRRCtttttttttttttttsSttttRRRRRRRRRSSR
                          sCccCt  CCcCsSRRRC   RRRRRRSctttttttttttttttCRRSRCtRRRRRRRRRRssRt
                          CsSSCct StsSstCCs   tRRRRSctttttttttttttttttCRCCStSRRRRRRRRRSSSSRt
                         tscSsSCcttR ttCstCCCCCccctttttttttttttttttttttttt tRRRRRRRSsRRRRRRs
                         sttSCsSccctcssSStCCCCCccttttttttttttttttsSSSsccCSRRRRSSRSSSstCRRRRSSC
                         C   tCsSsCcttcsRstCCCCsCCCccccccccttCRRSCCsRRRRRRRRSSSsssssssCRRRRRRSSS
                         t tRRRCsSSCCCsSRRRsctttttttttttCsRRRRRRStCRRRRRRRRSCCCccctttcCtRRRRRRRSSt
                        c cRccCcsSSSSSCtSScCRRRRSttttRCSRRRRRRRRRtSRRRRRRSCctttttttttttctRRRRSSSSSs
                        s sSCSscsst sSSCCtssRRRSS   ctttcsSRRRRRRtRRRRRRsccttttttttt ttCtRRRRSSSSSS
                      tSs SRssstCt  SSCSCt CScCsRs sCttttttcSRRRRRRRRRsctttttttttttt  tctcRRRRSSsSSs
                       Sc CRRRCCC  tSSCRRSt  CSSttsSttttttttttSRRRRRRSttttttttttttttt  tttRRRRRSssSCs
                        C  t   s   tsSStcCcCSRRttttttCCtCttttttcSRRRsttttttttCttttttt  tttSRRRRRSssRsc
                         cCt   t   tSSttttctsRStt   ttCcsctttttttRRsttttttttSCc ttttt  tttCRRRRRSSCRSCt
                           Ss t     Rctt ttttcRsttt tcCCsstttttttSCttttttttttCsttttttt ttttRRRRRRSsSRst
                            CRS     CS t  ttcccRSCttcCCsScStttttttttttttttttcCcttttttt ttttRRRRRRSsSRSC
                              C       Ct ttttcRRRRRRRSCSSSSttttttsStttttttttCCCt tttttttttcRRRRRRSssRRC
                                        SSSRRSsSRRRRRsRssCtStttttcsssCttttttCsCt tttttttttCRRRRRRSssRRC
                                       SsttttttCcRRRRSSSstS c ttS   ttRSttccCCCt tttttttttcSRRRRRSssRRs
                                      CRstt  tttCSRRRRRRSR  tSStt Ss stsRRSSSSSs tttttttttctcRRRSSssSRst
                                     tsRRtttttttSRSSRRRSRSStSRs S  tRtccsRRRRRRs ttttttttccRRRRRSSCsSRSt
                                     tSRRStttttsRSSRRRRRRRSsSRcts   SSstCSRRRRRs ttttttttctRRRRRSSCsSRSt
                                     tSRRRttttttssRSRRSRRRRSRRcSC   cRcCCsRRRRRs tttttttcctSRRRRSSsSSRSc
                                     tSRRRttttttCSRsSRRRRRRRRRCSR   RRtCCsRRRRRSSSSSSsCtcCtCRRRRSSssSRRs
                                     tsRRRRRSsssRSCsSSRRRRRRRRSCRRRRRRtcCsRRRRRSRRSSSSSRRRCcRRRRSSssSRRs
                                      ssRRRRRRRRsSsCCSSRRRRRRSRStSsRRSCCCSRRRRSRRRSsssSRRRRRRRRRRSSCSSRS
                                       CsSRRRRRRCSSsCsSSSRRRstCcSt CttsSSSSSSSRRRSssssSRRRRRRRRRRSSCsSRRt
                                        CsRRRRRRSsSSsCCsSSSRt ttttsSSsccCCssSRRRRSSsssSRRRRRRRRRRRSsCsSRC
                                      tCsSSssCssRCSCSCcCsSSS ttttttttttttcCCRRRRRSSSSSSRRRRRRRRRRRRsssSSSC
                                    CsSSSSSRRRRRRSsScSCCCsSS ttttcsc tttttcsRRRRRRSSSSRRRRRRRRRRRRRRSssSRSCt
                                  tcSSSSSSSSRRRRRRCSSSSCCCsRtt  ttcCttttttCSRRRSSSRRRRRRRRRRRRRRRRRRRSssSRSsC
                                tcCSSSSSSSSSSSRRRRSsSSSSCcSCt   ttcCt ttttSSSSSSSSSSSSSSSSSRRRRRRSSRRRSSsSSRSCCt
                               tcCSSSsssSSSSSSSRRRSCSRSSsSCSt   ttcCt ttttSRCsssssssssssSSSSSRRRRSSSSSSSssSSRSCssttt
                               cSSSSsCCssSSSSSSRRRRSRRSt tRRc   ttcCC ttttcttttttttttttcCssssRRRRRSSSSSSSSsssSSRSSss
                              cSSSsCcCCsSSSRSSRRRRRRsCSRRRRRS    ttCCtttts ttttttttttttttttcCCsRRRRSSsCSSSSSSSSSSSsS
                            tCsSsCCcCsSSSSRSSSRRRRRRRRRRRRRRRt   ttcCtttts tCctttttttttttttcCCCcRRRSSCStRSSSSSSSsCt
                           tcSSsCccCSSSSRRSSSSRRRRRRRRRRRRRRRS t sccCstttStCSctttttttttCCCCCCCcccRSSSCS   tsSSCt
                          tcSSsCcCssSSSSC SSSSRRRRRRRSSSSRRRRRc CscCSSstttcCRcttttttcCCsSsCCcttctSSSScSt
                          CCSSscCsSSSC   tsSSSRRRRRSSsSSSSRRRRRttSctSSSRRRRRRctttttcCsCttttctttccSSSSCsc
                         tCsSsCCsSSs     CSSSSRRRSSsCsSSSSSRRRRSttRSscRstCttSsttttCccctttttctcttSRRSSSCR
                         cCSSsSSSCt      SSSSSRRSssssSSSSSSRRRRSttstcSs tttcRsttttttCCCtttctCSSSSRRRRSSCt
                         CsSSSSst        SSSSSRRSssSs    tRRRRRtttctCSStCStcRSttttttCCCcctCt     csRRRRRSSt
                         CSSSSs          cCSSSSSSSSt      sRRRs ttctCSRRSSSSRSttttttCCSRSs           tcCt
                         CSSsc            ssSSSSsS        CRRSsRRSctSsSSSSSsSSttttttCcsSSS
                         CSsCt            RCSSSSSC        sRRsSSSRCtsSSSSSSSRRtttttccCRRRSC
                         CCC               RssSSs        CsRSsSssRCCRRSSSRRRSSRScttCRRRRRRSc
                         tt                 cRss        CsRRSSsCsRRSSStcSRRRssSSSRRRRRSSRRRSC
                         t                    CR       ssC sSSssSRRSSs tSRRRCCSSSRRSSSSSSRRRs
                                                      st  cSSssSRRRSSC tSRRRCcSSSRRSsssSSRRRRSt
                                                         CsRRSSRRRRSSC tSRRRctSSSRRSssSSRRRRRRSs
                                                  csSsssSSSSSSRRRRRSSC cSRRRCtsSSRSSSSSRRRSSSSSSSt
                                                sCsSSRRRRRRRRRSRRRRsSCtcSRRRCtCSSRRSSRRSSRRRRRSSSSSSSSSc
                                               CsSRRRRRRRRRRRRRRSRSsSCCCSRRRCtcSSRRRRSSRRRRRRRRRRRRRRSCs
                                               SSRRRRRRRRRRRRRRRRRSsSC tSRRRsttsSSRSSRRRRRRRRRRRRRRRRRSCt
                                               SSRRRRRRRRRRRRRRRRSSSSCctsRRRSctcSSSRRRRRRRRRRRRRRRRRRRRSC
                                               SSRRRRRRRRRRRRRRRRSSsSCCcCSRRSsCCSSRRRRRRRRRRRRRRRRRRRRRSC
                                              sSRRRRRRRRRRRRRRRRRSssScttCSRRSSssSSRRRRRRRRRRRRRRRRRRRRRSC
                                               tSSSSsSSSSRRRRRRRSRRSSCcccsscRRSSsCSSSSSRRRRRRRRRRRRSSSSRs
                                                     cCSSSRRRSst  tSCCssCCcst        tsSSsssSSSSSSSSssSSRt
                                                                                         tCSSSSSSSSSSRSs


